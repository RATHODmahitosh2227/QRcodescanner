let html5QrcodeScanner;

function onScanSuccess(qrCodeMessage) {
    document.getElementById('resultText').innerText = qrCodeMessage;
    // Stop scanning after a successful scan
    if (html5QrcodeScanner) {
        html5QrcodeScanner.clear();
        document.getElementById('stopButton').disabled = true;
        document.getElementById('startButton').disabled = false;
    }
}

function onScanError(errorMessage) {
    // Optionally handle scan errors
    console.warn(`QR code scan error: ${errorMessage}`);
}

document.getElementById('startButton').addEventListener('click', () => {
    html5QrcodeScanner = new Html5Qrcode("reader");
    html5QrcodeScanner.start(
        { facingMode: "environment" }, 
        { fps: 10, qrbox: { width: 250, height: 250 } })
        .then(() => {
            document.getElementById('stopButton').disabled = false;
            document.getElementById('startButton').disabled = true;
        })
        .catch(err => {
            console.error(`Unable to start scanning: ${err}`);
        });
});

document.getElementById('stopButton').addEventListener('click', () => {
    if (html5QrcodeScanner) {
        html5QrcodeScanner.clear();
        document.getElementById('stopButton').disabled = true;
        document.getElementById('startButton').disabled = false;
    }
});
